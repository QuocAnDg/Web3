import { useState, useEffect } from 'react'

const AboutPage = () => {
    return (
     <h1>ABOUT JOE MAMA</h1>
    );
}
export default AboutPage;

